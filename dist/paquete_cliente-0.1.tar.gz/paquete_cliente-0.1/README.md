# Segunda pre-entrega-brizuelaLucas
 Segunda pre entrega del proyecto final del curso Python en Coderhouse, comisión 60070
Alumno: Brizuela Lucas Matias
# Objetivo
Practicar el concepto de clases y objetos

# Consigna
Crear un programa que permita el modelamiento de Clientes en una página de compras, utilizando el concepto de POO.

# Instalación
Se puede instalar este utilizando el comando pip:

```bash
pip install nombre_del_paquete